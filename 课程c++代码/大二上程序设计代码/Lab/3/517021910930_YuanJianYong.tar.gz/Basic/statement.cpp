/*
 * File: statement.cpp
 * -------------------
 * This file implements the constructor and destructor for
 * the Statement class itself.  Your implementation must do
 * the same for the subclasses you define for each of the
 * BASIC statements.
 */

#include <string>
#include <iostream>
#include "statement.h"
#include "../StanfordCPPLib/strlib.h"
using namespace std;

/* Implementation of the Statement class */

Statement::Statement() {
   /* Empty */
}

Statement::~Statement() {
   /* Empty */
}


SequentialSta::SequentialSta(string _name,Expression *_content){
   content = _content;
   instructName = _name;
}

SequentialSta::~SequentialSta(){
	delete content;
}

int SequentialSta::getContentVal(EvalState &state){
   return content->eval(state);
}

string SequentialSta::getType(){
	return instructName;
}

void SequentialSta::execute(EvalState &state){
   if (instructName == "REM")
   {
       return;//comment
   }
      
   if (instructName == "LET")
   {
        if (content->getType()==COMPOUND && content->getOp()=="=")
	{
		content->eval(state);  //eval it
		return;
	}
	else
		error("unfinish");

   }
   
   if (instructName == "PRINT")
   {
	   //PRINT a=1 is illegal
	if (content->getType()==COMPOUND&&content->getOp()=="=")
		error("SYNTAX ERROR");
	cout << (content->eval(state)) << endl;
	return;
   }
      
   if (instructName == "INPUT")
   {
        if (content->getType()!=IDENTIFIER)
		error("SYNTAX ERROR");  //INPUT 520 is illegal
	else
	{
		bool success = 0;
		int value;
		string strValue = "";
		while (1)
		{
			//ask for an input until get a legal one
			success = 1;
			cout<<" ? ";
			getline(cin,strValue);
			for (int i=0;i<strValue.size();i++)
				if (strValue[i]!='-'&&strValue[i]!='+'&&(strValue[i]-'0'<0||strValue[i]-'0'>9))
				{
					success = 0;
					cout << "INVALID NUMBER"<<endl;
					break;
				}
			if (success)
			{
				value = stringToInteger(strValue);
				break;
			}
		}
		state.setValue(content->toString(),value);
		return;
	}
   }
      
   if (instructName == "END")
   {
        //need to do nothing but just use getNextLineNumber to end the program
	return;
   }
      
   else
	   error("SYNTAX ERROR");

}

IfThen::IfThen(CompoundExp *_condition,int _num){
	condition = _condition;
	num = _num;
}

IfThen::~IfThen(){
	delete condition;
}

void IfThen::execute(EvalState &state){
	//the same as END and GOTO
	return;
}

string IfThen::getType(){
	return "IFTHEN";
}

int IfThen::getNum(){
	return num;
}

bool IfThen::conditionOK(EvalState &state){
	if (condition->getOp()=="=")
		return condition->getLHS()->eval(state)==condition->getRHS()->eval(state);
	
	if (condition->getOp()=="<")
		return condition->getLHS()->eval(state)<condition->getRHS()->eval(state);
	
	if (condition->getOp()==">")
		return condition->getLHS()->eval(state)>condition->getRHS()->eval(state);
	error("SYNTAX ERROR");
}



Goto::Goto(int _num){
	num = _num;
}

void Goto::execute(EvalState &state){
	//the same as IfThen and END
	return;
}

string Goto::getType(){
	return "GOTO";
}

int Goto::getNum(){
	return num;
}
