/*
 * File: statement.h
 * -----------------
 * This file defines the Statement abstract type.  In
 * the finished version, this file will also specify subclasses
 * for each of the statement types.  As you design your own
 * version of this class, you should pay careful attention to
 * the exp.h interface specified in Chapter 17, which is an
 * excellent model for the Statement class hierarchy.
 */

#ifndef _statement_h
#define _statement_h

#include "evalstate.h"
#include "exp.h"

/*
 * Class: Statement
 * ----------------
 * This class is used to represent a statement in a program.
 * The model for this class is Expression in the exp.h interface.
 * Like Expression, Statement is an abstract class with subclasses
 * for each of the statement and command types required for the
 * BASIC interpreter.
 */

class Statement {

public:

/*
 * Constructor: Statement
 * ----------------------
 * The base class constructor is empty.  Each subclass must provide
 * its own constructor.
 */

   Statement();

/*
 * Destructor: ~Statement
 * Usage: delete stmt;
 * -------------------
 * The destructor deallocates the storage for this expression.
 * It must be declared virtual to ensure that the correct subclass
 * destructor is called when deleting a statement.
 */

   virtual ~Statement();

/*
 * Method: execute
 * Usage: stmt->execute(state);
 * ----------------------------
 * This method executes a BASIC statement.  Each of the subclasses
 * defines its own execute method that implements the necessary
 * operations.  As was true for the expression evaluator, this
 * method takes an EvalState object for looking up variables or
 * controlling the operation of the interpreter.
 */

   virtual void execute(EvalState & state) = 0;
/*
 * Method: getType
 * Usage: stmt->getType();
 * -----------------------
 *  This method return the type of statement,including SequentialSta,IFTHEN,GOTO
 *  for SequentialSta, return the name of the instruct.
 */
   virtual string getType() = 0;
};

/*
 * The remainder of this file must consists of subclass
 * definitions for the individual statement forms.  Each of
 * those subclasses must define a constructor that parses a
 * statement from a scanner and a method called execute,
 * which executes that statement.  If the private data for
 * a subclass includes data allocated on the heap (such as
 * an Expression object), the class implementation must also
 * specify its own destructor method to free that memory.
 */
class SequentialSta:public Statement{
	public:
		/* Constructor: SequentialSta
		 * Usage: SequantialSta ss(string s,Expression *cont);
		 * ---------------------------------------------------
		 * This method construct a SequentialSta
		 */

		SequentialSta(string _name,Expression *_content);
		
		/* Destructir: ~SequentialSta()
		 * ----------------------------
		 *  delete the Expression * member
		 */

		~SequentialSta();

		/* Method: getContentVal
		 * Usage: int val = ss->getContentVal(state);
		 * ------------------------------------------
		 * return the value of the Expression
		 */
		
		int getContentVal(EvalState &state);
		
		/* Method: getType
		 * Usage: string s = ss->getType()
		 * -------------------------------
		 * return the name of the instruct
		 */
		
		virtual string getType();
		
		/* Method: execute
		 * Usage: ss->execute(state);
		 * --------------------------
		 * do the special thing according to the instruct name
		 */
		
		virtual void execute(EvalState &state);

	private:
		string instructName;
		Expression *content;
};

class IfThen:public Statement{
	public:
		/* Constructor: IfThen
		 * -------------------
		 * consist of a CompoundExp*, which represents the condition
		 * and an int number, represent the number of line u want to 
		 * Then to.
		 */

		IfThen(CompoundExp *condition,int num);
		
		/* Destructor: ~IfThen
		 * -------------------
		 * delete the CompoundExp pointer
		 */

		~IfThen();
		
		virtual void execute(EvalState &state);
		virtual string getType();

		/* Method: conditionOK
		 * Usage: bool flag = IT->conditionOK(state)
		 * -----------------------------------------
		 * judge whether the condition is satisfied,
		 * like: 1+1<3 return false; a = 15 judge according to the real
		 * value of a, if a==5,return true else false; b > c.......
		 */

		bool conditionOK(EvalState &state);

		/* Method: getNum
		 * Usage: int num = IT->getNum()
		 * -----------------------------
		 * get the number behind Then, which represents the line number
		 */

		int getNum();
	private:
		CompoundExp *condition;
		int num;//maybe num > 32767?
};

class Goto:public Statement{
	public:
		/* Constructor
		 * the int member is the line number you want to goto
		 */

		Goto(int num);

		/* Method: execute
		 * Usage: GOTO->execute(state)
		 * ---------------------------
		 * do nothing but just return
		 */

		virtual void execute(EvalState &state);
		
		/* Method: getType
		 * Usage: GOTO->getType()
		 * ----------------------
		 * return the string "GOTO"
		 */

		virtual string getType();
		
		/* Method: getNum
		 * Usage: GOTO->getNum()
		 * ---------------------
		 *  the same as IFTHEN, return the line number you want to goto
		 */

		int getNum();
	private:
		int num;
};
#endif
