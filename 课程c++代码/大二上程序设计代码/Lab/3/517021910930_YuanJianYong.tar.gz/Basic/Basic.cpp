/*
 * File: Basic.cpp
 * ---------------
 * Name: [TODO: enter name here]
 * Section: [TODO: enter section leader here]
 * This file is the starter project for the BASIC interpreter from
 * Assignment #6.
 * [TODO: extend and correct the documentation]
 */

#include <cctype>
#include <iostream>
#include <string>
#include <sstream>
#include "exp.h"
#include "parser.h"
#include "program.h"
#include "../StanfordCPPLib/error.h"
#include "../StanfordCPPLib/tokenscanner.h"

#include "../StanfordCPPLib/simpio.h"
#include "../StanfordCPPLib/strlib.h"
using namespace std;

/* Function prototypes */

void processLine(string line, Program & program, EvalState & state);
void CompileInstruct(string,Program &,EvalState&,TokenScanner&);
/* Main program */

int main() {
   EvalState state;
   Program program;
   while (true) {
      try {
         processLine(getLine(), program, state);
      } catch (ErrorException & ex) {
         cout << ex.getMessage() << endl;
      }
   }
   return 0;
}

/*
 * Function: processLine
 * Usage: processLine(line, program, state);
 * -----------------------------------------
 * Processes a single line entered by the user.  In this version,
 * the implementation does exactly what the interpreter program
 * does in Chapter 19: read a line, parse it as an expression,
 * and then print the result.  In your implementation, you will
 * need to replace this method with one that can respond correctly
 * when the user enters a program line (which begins with a number)
 * or one of the BASIC commands, such as LIST or RUN.
 */

void processLine(string line, Program & program, EvalState & state) {
   TokenScanner scanner;
   scanner.ignoreWhitespace();
   scanner.scanNumbers();
   scanner.setInput(line);
   string instruct = scanner.nextToken();
   string lineNum;
   int num = 0;
   stringstream ss;

   if (scanner.getTokenType(instruct)==TokenType(EOF))
	   return;
   if (scanner.getTokenType(instruct)==WORD)
   {
	   //may be this is a Basic command, compile it!
	   CompileInstruct(instruct,program,state,scanner);
	   return;
   }
   if (scanner.getTokenType(instruct)==NUMBER)
   {
	//may be this is a program line, parse it
	
	lineNum = instruct;
	//convert string to int
	ss.clear();
	ss << lineNum;
	ss >> num;
	instruct = scanner.nextToken();//unfinish
	if (instruct=="")
		program.removeSourceLine(num);
	else
	{
		program.addSourceLine(num,line);
	}
	return;
   }
   else
	   error("SYNTAX ERROR");
}

/* Function: CompileInstruct
 * Usage: CompileInstruct(instruct,program,state,scanner);
 * ------------------------------------------------------
 * this function is used to deal with the commands control the Basic Interpreter
 * and those can be executed directly
 */

void CompileInstruct(string instruct, Program & program, EvalState & state,TokenScanner &scanner){
if (instruct=="RUN")
{
	program.run(state);
	return;
}
if (instruct=="LIST")
{
	program.list();
	return;
}

if (instruct=="CLEAR")
{
	program.clear();
	state.clear();
	return;
}
if (instruct=="QUIT")
{
	exit(0);
}
if (instruct=="HELP")
{
	cout<<"this is a basic interpreter"<<endl;
	return;
}
if (instruct=="LET"||instruct=="PRINT"||instruct=="INPUT")
{
	Expression *exp = parseExp(scanner);
	Statement *sta = new SequentialSta(instruct,exp);//unfinished
	sta->execute(state);
	return;
}
error("SYNTAX ERROR");
}
