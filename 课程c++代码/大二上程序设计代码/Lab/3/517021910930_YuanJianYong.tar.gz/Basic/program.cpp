/*
 * File: program.cpp
 * -----------------
 * This file is a stub implementation of the program.h interface
 * in which none of the methods do anything beyond returning a
 * value of the correct type.  Your job is to fill in the bodies
 * of each of these methods with an implementation that satisfies
 * the performance guarantees specified in the assignment.
 */

#include <string>
#include <sstream>
#include "../StanfordCPPLib/strlib.h"
#include "program.h"
#include "statement.h"
using namespace std;

Program::Program() {
	/*empty*/
}

Program::~Program() {
  clear();
}

void Program::clear() {
	//clear all the lines
  for (int i = 0; i < lines.size();i++)
  {
	  delete lines[i].second.statement;
  }
  lines.clear(); 
}

void Program::addSourceLine(int lineNumber, string line) {
	//all check work and parse work is done in this function
  Line newLine;
  stringstream ss;
  ss << lineNumber;
  newLine.source = line;
  line.erase(0,ss.str().size());  //remove the number at the beginning of line

  TokenScanner scanner;
  scanner.ignoreWhitespace();
  scanner.setInput(line);
  string instruct = scanner.nextToken();
  if (scanner.getTokenType(instruct)!=WORD)
	  error("SYNTAX ERROR");
	
  //parse every situation
  if (instruct=="REM")
  {
	newLine.statement = new SequentialSta(instruct,NULL);
  }
  else if (instruct=="END")
  {
	  if (scanner.nextToken()!="")
		  error("SYNTAX ERROR");
	  newLine.statement = new SequentialSta(instruct,NULL);
  }
  else if (instruct=="LET"||instruct=="INPUT"||instruct=="PRINT")
  {
	  Expression *exp = parseExp(scanner);
	  if (scanner.nextToken()!="")
		  error("SYNTAX ERROR");  //have more token
	  newLine.statement = new SequentialSta(instruct,exp);
  }
  else if(instruct == "IF")
  {
	Expression *Condition = parseExp(scanner,1);  //parse the condition
	if (Condition->getType()!=COMPOUND||precedence(Condition->getOp())!=1)
		error("SYNTAX ERROR");
	if (scanner.nextToken()!="THEN")
		error("SYNTAX ERROR");

	string stringnum = scanner.nextToken();
	if (scanner.nextToken()!="")
		error("SYNTAX ERROR");
	int num = stringToInteger(stringnum);  //the number of next line

	CompoundExp *specifiedCondition = dynamic_cast<CompoundExp*>(Condition);
	newLine.statement = new IfThen(specifiedCondition,num);
  }
  else if(instruct == "GOTO")
  {
	string stringnum = scanner.nextToken();
	if (scanner.nextToken()!="")
		error("SYNTAX ERROR");
	int num = stringToInteger(stringnum);  //the number of next line
	newLine.statement = new Goto(num);
  }
  else
	error("SYNTAX ERROR");
  if (lines.empty())
  {
	 lines.push_back(make_pair(lineNumber, newLine));
  }
  else
  {
	  //insert the newLine into the lines vector in right order
	  int i = 0;
	  for (;i < lines.size(); i++)
	  {
		  if (lines[i].first == lineNumber)
		  {
			  delete lines[i].second.statement;
			  lines[i].second = newLine;
			  break;
		  }
		  if (lines[i].first > lineNumber)
		  {
	  		lines.insert(lines.begin()+i,make_pair(lineNumber,newLine));
			break;
		  }
		  if (i==lines.size()-1)
		  {
			lines.push_back(make_pair(lineNumber,newLine));
			break;
		  }
	  }
  }
}

void Program::removeSourceLine(int lineNumber) {
   for (int i = 0;i < lines.size();i++)
   {
	   if (lines[i].first == lineNumber)
	   {
		   delete lines[i].second.statement;
		   lines.erase(lines.begin()+i);
		   return;
	   }
   }
   return;
}

string Program::getSourceLine(int lineNumber) {
   for (int i = 0;i < lines.size();i++)
   {
	   if (lines[i].first == lineNumber)
	   {
		return lines[i].second.source;
	   }
   }
   return "";
}

void Program::setParsedStatement(int lineNumber, Statement *stmt) {
   
   for (int i = 0;i < lines.size();i++)
   {
	   if (lines[i].first == lineNumber)
	   {
		delete lines[i].second.statement;
		lines[i].second.statement = stmt;
		return;
	   }
   }
   error("no such line exits");
}

Statement *Program::getParsedStatement(int lineNumber) {

   for (int i = 0;i < lines.size();i++)
   {
	   if (lines[i].first == lineNumber)
	   {
		return lines[i].second.statement;
	   }
   }
   return NULL; 
}

int Program::getFirstLineNumber() {
   if (lines.empty())
   {
	   return -1;
   }
   return lines[0].first;    
}

int Program::getNextLineNumber(int lineNumber,EvalState &state) {
	//control the next line, especial for IF .. THEN .. and GOTO ..
   for (int i = 0;i<lines.size();i++)
   {
	   if (lines[i].first==lineNumber)
	   {
		if (lines[i].second.statement->getType()=="GOTO")
		{
			int tmp = ((Goto *)lines[i].second.statement)->getNum();
			return tmp;
		}
		if (lines[i].second.statement->getType()=="IFTHEN")
		{
			IfThen *tmp = dynamic_cast<IfThen *>(lines[i].second.statement);
			if (tmp->conditionOK(state))
				return tmp->getNum();
		}
		if (i == lines.size()-1||lines[i].second.statement->getType()==
				"END")
			return -1;  //reach the end
		return lines[i+1].first;  //if nothing special, in order.
	   }
	   
   }
   error("LINE NUMBER ERROR");
}

void Program::run(EvalState &state)  {
	//just execute the current line's statement and then get the next line
int lineNumber = getFirstLineNumber();
while (lineNumber!=-1)
{	
   for (int i = 0;i < lines.size();i++)
   {
	   if (lines[i].first == lineNumber)
	   {
		   lines[i].second.statement->execute(state);
		   break;
	   }
   }
   lineNumber = getNextLineNumber(lineNumber,state);
}
}

void Program::list() {
	for (int i = 0;i < lines.size();i++)
	{
		cout << lines[i].second.source <<endl;
	}
}
